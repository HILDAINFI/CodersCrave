# URL-Shortener-Website
URL Shortener Website using simple HTML, CSS, JS and API fetch with no API KEY Needed. Check out the full video on my YouTube channel @allcsstuff

## View the Website: 
https://allcsstuff.github.io/URL-Shortener-Website/

## My YouTube channel Link :
https://www.youtube.com/@allcsstuff

## Screenshot 

![Url Shortener](https://github.com/allcsstuff/URL-Shortener-Website/assets/127939979/0da9b5c4-9eec-43f7-840e-93429258a0c8)

## License

[MIT](https://github.com/allcsstuff/URL-Shortener-Website/blob/master/LICENSE)
